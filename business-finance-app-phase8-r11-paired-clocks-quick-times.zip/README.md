# Business Ledger — Phase 8, Revision 11

Current build: **Paired Clocks + Client Quick Times**. Work sessions use independent start/end clocks with a live duration/value summary and three reusable time-pair shortcuts per client.

Revision 11 keeps the existing session source fields and validation intact while turning the entry surface into a calmer, faster interaction. Quick times are lightweight workspace/client preferences rather than financial records, and switching clients changes only the three corresponding shortcuts.

## Typography scale refinement

All explicit interface typography has been increased slightly while preserving the existing hierarchy: compact labels receive about +1px, normal interface text about +7%, and large display/title text about +5%. Compact text-bearing controls receive minor breathing-room adjustments to avoid crowding. No business logic or data model behavior changed.

# Phase 5 — Taxes / Mileage + Vehicles Alpha

This checkpoint adds a fifth permanent destination: **Home → Work → Money → Taxes → Records**. The new Taxes area begins with Mileage + Vehicle Tracking and is intentionally designed as the future home for Phase 6 tax interpretation.

## Active Phase 5 behavior
- Vehicle profiles with year/make/model, optional nickname, active/inactive status, optional odometer, notes, and one primary vehicle.
- Mileage source records with date, vehicle, miles, Business/Personal classification, optional start/end labels, business purpose, client/session linkage, notes, and Needs Review state.
- Mileage filters for All / Business / Personal / Needs Review and seven-record pagination.
- Tax summary metrics for this-month business miles, all-time business miles, primary vehicle, and review count.
- Vehicle summary cards with linked trip count, business miles, and odometer.
- Edit/delete/detail flows for trips and vehicles, including audit events and snapshot preservation when linked work/vehicles are later removed.
- Home Attention now includes mileage records that need review.
- Global search now finds Taxes, mileage trips, and vehicles.
- Quick Add includes Mileage.
- Schema version 7 migrates existing Phase 4 local data without changing invoices, payments, expenses, receipts, clients, or sessions.

## Design rules
- Mileage is a source record, **not an expense**. A trip can later be interpreted by tax logic without pretending money left the account.
- Phase 5 records driving facts and business context; it does **not** decide tax deductibility or compute a mileage deduction.
- Client/session links are optional and keep snapshots so history remains understandable after linked records are removed.
- The Taxes page uses the existing Corporate Atrium + Frosted Window Bays system and the Safari/iPad no-flash profile.

## Suggested Phase 5 test
1. Open Taxes and add a vehicle; confirm the first active vehicle becomes Primary.
2. Add a Business mileage trip with a purpose and verify it appears in Trip history and summary miles.
3. Add a Personal trip and verify it does not increase Business miles.
4. Add a Business trip without a purpose; verify it becomes Needs Review and appears on Home → Attention.
5. Mark that trip reviewed and confirm it leaves Attention.
6. Link a trip to a client/session, then open its detail view and verify the work context.
7. Delete the linked session/client and confirm the mileage record survives with snapshots.
8. Add a second vehicle, make it Primary, and verify the prior Primary clears.
9. Delete a vehicle with mileage; confirm the trips remain with the saved vehicle-name snapshot.
10. Search for a vehicle or mileage purpose from global search and confirm navigation opens the correct record.

## Still deferred
- Tax deduction eligibility/rules, mileage rates, Schedule C mapping, estimated taxes, and tax-year calculations (Phase 6).
- Automatic GPS/route capture and advanced mileage automation (Phase 12).
- Backup restore/import.
- Secure cloud authentication/sync.

## Frosted Window Bays Alpha

This build applies the selected **Frosted Window Bays** material direction across the four main Corporate Atrium tabs. Main information surfaces now use cool gray-blue architectural frost, restrained luminous borders, localized background blur, and softer window-like highlights so the atrium remains visible through the interface. Semantic color is kept primarily in labels, chips, and status indicators instead of tinting whole cards.

The established iPad/Safari stability profile remains in place: the atrium itself stays fixed, expensive motion is avoided, and touch/Safari devices use lower blur with slightly stronger pane opacity. Business logic, data models, workflows, modals/detail sheets, and receipt/invoice behavior are unchanged.

## Corporate Atrium — Records tab

- Extended the proven Home + Work + Money Corporate Atrium scene to the Records view without changing receipt-vault behavior or stored data.
- Records now shares the same embedded atrium plate, subtle dynamic architectural lighting, and stable Safari/iPad rendering profile.
- The Records heading, export action, receipt search/count controls, receipt evidence cards, empty state, and local-storage note now use the same smoked-glass/material language with stronger text contrast.
- Receipt/expense detail sheets and modals remain on the existing Phase 4 modal treatment; this pass themes the Records tab itself only.


## Corporate Atrium — Money tab

- Extended the proven Home + Work Corporate Atrium scene to the Money view without changing invoice, payment, or expense business logic.
- Money now shares the same embedded atrium plate, stable iPad/Safari lighting profile, and subtle dynamic architectural lighting.
- Money-specific surfaces (metric cards, invoice/payment/expense ledgers, filters, pagination, and actions) use dense smoked glass with semantic green/amber/red casts.
- Invoice/payment/expense modals and detail sheets remain on the existing Phase 4 modal treatment for now; only the Money tab itself was themed in this pass.

## Corporate Atrium — Work tab extension

- The proven Home atrium environment is now also active on the Work tab.
- Work keeps its existing Sessions/Clients structure and functionality, but its heading, actions, segment control, search/filter controls, session table, pagination, and client cards now use the same smoked-glass/material system.
- The existing subtle architectural-light animation continues on Work without moving the large background image.
- Safari/iPad retains the lite rendering profile with reduced blur on large Work surfaces for smooth scrolling.
- Money and Records remain on the prior theme for now.

## Corporate Atrium embedded-scene fix

- The approved atrium photograph is now embedded directly in `styles.css` as a data URI. This removes the failure mode where the app silently fell back to the synthetic dark SVG because the nested `assets/atrium-primary.jpg` file was missing, stale, or not uploaded to GitHub Pages.
- Added cache-busting query versions to `styles.css` and `app.js` for deployment testing.
- Reduced synthetic light-rail opacity and global darkening so the actual glass walls, skyline, plants, seating, and reflective marble floor remain clearly visible.
- iPad/Safari keeps the stabilized non-scroll-linked motion profile.

## Stability pass highlights

- Replaced third-party atrium image dependency with a bundled local background asset so Home no longer depends on remote image hosts.
- Removed scroll-linked atrium motion and added an automatic lite profile for iPad/Safari/coarse-pointer environments to reduce shimmer and static during scrolling.
- Reduced blur and glass complexity on the Home scene for more stable rendering while preserving the atrium look.

# Business Ledger — Phase 4 Expenses Alpha

This checkpoint activates the outgoing-money side of Business Ledger while preserving the existing Client → Session → Invoice → Payment architecture.

## Active workflows

- Multi-workspace business/gig separation
- Clients with visual color identities
- Work sessions with rate snapshots and 5-minute radial time entry
- Invoices, partial/full payments, and direct income
- Expenses with Business / Mixed / Personal use classification
- Separate original total and business-use amount
- Streamlined bookkeeping categories: Food, Gas, Parking, Car, Subscriptions, Misc, Fees, and Work Equipment
- Business-purpose notes and optional client/session linking
- Needs Review queue integrated with Home Attention
- Optional receipt image/PDF attachment
- Receipt Vault in Records with merchant/category/file search
- Direct filter menus and 7-record pagination across long financial lists
- Workspace-local date logic using America/Los_Angeles for Play It Forward

## Receipt storage

Structured financial records remain in browser localStorage through the versioned LocalRepository. Receipt file bytes are stored separately in browser IndexedDB so image/PDF data is not embedded in the expense JSON.

This remains a local prototype. Do not treat it as secure production storage for sensitive client or tax documents yet.

The current JSON backup contains the structured expense and receipt metadata, but **does not package the receipt file bytes**. Restore/import is still intentionally deferred.

## Expense design rules

- `totalCents` records what was actually spent.
- `businessCents` records the business-use portion without destroying the original amount.
- Business classification = 100% business portion.
- Personal classification = $0 business portion.
- Mixed classification requires a business portion between $0 and the total.
- Expense category is bookkeeping context, **not a tax deduction decision**.
- A missing business-purpose note on Business/Mixed entries automatically sends the expense to Needs Review.
- Receipts are optional and remain evidence linked to the expense rather than determining the accounting amount.

## Suggested Phase 4 test

1. Add a Business expense with a purpose and no receipt.
2. Add a Mixed expense and verify the business portion cannot exceed/equal the total.
3. Add a Personal expense and confirm its business portion remains $0.
4. Attach an image or PDF receipt and confirm it appears in Records → Receipt Vault.
5. Edit the expense and replace/remove the receipt.
6. Mark an expense Needs Review and confirm it appears on Home → Attention.
7. Mark it reviewed from the expense detail panel and confirm it disappears from Attention.
8. Link an expense to a client/session and verify the context appears in expense detail.
9. Test the Expenses filter and pagination with more than seven records.
10. Search receipt file names/merchants/categories from Records.
11. Refresh the browser and verify the structured records and local receipt remain available.

## Deferred by design

- Backup restore/import
- Mileage and vehicles (Phase 5)
- Tax deduction logic / Schedule C mapping (Phase 6)
- Full evidence/audit drill-down (Phase 7)
- Bank transaction importing and reconciliation (Phase 11)
- Secure cloud authentication/sync and encrypted file storage

## Phase 4 usability refinement 1
Desktop/tablet layouts now support an optional collapsible left sidebar. Use the small edge chevron to collapse the navigation; the sidebar fades/slides away and the main workspace expands to use the reclaimed width. Press the same control again to restore the full sidebar. The preference is stored locally. Mobile bottom navigation is unchanged.

### Refinement 2 — default collapsed navigation + fluid top bar
On a fresh desktop/tablet visit, Business Ledger opens on Home with the sidebar collapsed to maximize usable workspace. The edge chevron remains visible with a subtle traveling accent glow as a discoverability cue. Once the user expands/collapses it, that preference is saved locally for later visits. The sticky top utility area now fades into the page with a gradient blur rather than presenting as a hard translucent rectangle while scrolling.

### Top utility blending
The sticky search/profile region intentionally avoids applying a full-width backdrop blur. A short page-colored fade now protects control readability while allowing bright underlying text and cards to pass beneath without turning into a broad gray haze.

## Corporate Atrium Home prototype
The Home view now uses the Corporate Atrium visual system while the rest of Phase 4 remains visually unchanged for A/B review. The environment uses remote Unsplash image plates with a bundled SVG fallback. Unsplash source references used for the prototype environment:
- E Vos — “Modern office interior with glass walls and walkways” (Unsplash, free under the Unsplash License).
- Fer Troulik — “Modern office interior with glass walls and reflections” (Unsplash, free under the Unsplash License).

No people animation or randomized ambient events are active in this build.

## Safari scroll stability pass

This build specifically reduces the small visual snap that can occur when iPad/iPhone Safari collapses or expands its browser chrome during the first scroll. The atrium scene now uses a stable large-viewport (`lvh`) canvas rather than a fixed element constrained by both `top` and `bottom`, while themed page minimum heights use the stable small viewport (`svh`). Height-only Safari resize events are ignored by the atrium runtime; true width changes such as rotation and Split View still refresh the layout. The browser's own toolbar collapse still changes how much of the webpage is visible, but the app should no longer re-crop/re-scale the photographic background at the same moment.

### Phase 6 Tax Layer
The Taxes workspace now includes Overview, Mileage, Vehicles, and Deductions. It summarizes a selected tax year from existing source records, applies date-aware standard-mileage planning rates, surfaces review gaps, and provides quarterly planning context. It does not prepare a return or calculate final federal/state tax liability.
# Business Ledger — Phase 7 Traceability / Evidence

Phase 7 adds evidence drill-through and record history to the completed Phase 6 tax layer. Derived tax figures can now be reconciled to their contributing Payments, Expenses, and Mileage records without creating a new navigation destination or altering source data. Schema v9 also preserves structured final snapshots for newly deleted records.
# Business Ledger — Phase 8 Dashboard / Analytics

Phase 8 expands Home with a calm analytics workspace. It adds selectable ranges, prior-period comparisons, monthly business-flow and work trends, client/source income and workload, expense-category patterns, invoice collection health, and full source-record drill-through. All analytics are calculated at render time from the existing Phase 7 source-of-truth model.
# Phase 8 Analytics Chart Refinement

This refinement adds proportional currency axes, a continuously scrubbable monthly net-movement chart, a separate Income vs Expenses trend, and small traceable donut charts for income sources and expense categories. Every visualization responds to the Analytics date-range control and remains derived from authoritative source records.

# Entry Memory + Expense Category Refinement

Successful new entries now remember their recurring selections per workspace. New expenses reopen with the last submitted classification and category; the same principle also carries forward relevant selections for payments, sessions, invoices, mileage, clients, and vehicles. On the first use after this update, compatible choices are inferred from the newest existing record. Explicit launch context—such as recording a payment from a specific invoice—continues to take priority. Abandoned forms and edits do not change these defaults.

New expense entries use Food, Gas, Parking, Car, Subscriptions, Misc, Fees, and Work Equipment. Existing expenses retain their original saved category and label, including when edited or viewed in historical analytics and tax summaries.
