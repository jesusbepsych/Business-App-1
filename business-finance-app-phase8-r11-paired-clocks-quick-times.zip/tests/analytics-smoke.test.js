const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const indexHtml = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const completeCss = fs.readFileSync(path.join(__dirname, '..', 'styles.css'), 'utf8');
assert.match(indexHtml, /styles\.css\?v=phase8-r11-paired-clocks-quick-times/);
assert.match(indexHtml, /app\.js\?v=phase8-r11-paired-clocks-quick-times/);
assert.equal((indexHtml.match(/gold-segment-bar/g) || []).length, 4);
assert.ok(completeCss.length > 700000, 'complete stylesheet should not be truncated');
assert.match(completeCss, /--atrium-scene-image:\s*url\("data:image\/jpeg;base64,/);
assert.match(completeCss, /\.home-atrium-scene\s*\{/);
assert.match(completeCss, /\.atrium-photo-primary\s*\{/);
assert.match(completeCss, /\.home-tab\{display:none\}/);
assert.match(completeCss, /\.home-tab\.active\{display:block/);
assert.match(completeCss, /\.chart-scrubber/);
assert.match(completeCss, /\.donut-slice/);
assert.match(completeCss, /\.expense-compose-sheet/);
assert.match(completeCss, /\.payment-compose-sheet/);
assert.match(completeCss, /\.gold-segment-bar::after/);
assert.match(completeCss, /@keyframes goldSegmentShimmer/);
assert.match(completeCss, /padding:1\.65px/);
assert.match(completeCss, /drop-shadow\(0 0 4px rgba\(236,181,69,\.28\)\)/);
assert.match(indexHtml, /id="invoiceCalendarGrid"/);
assert.match(indexHtml, /id="invoiceClientChangeConfirm"/);
assert.match(indexHtml, /Touch a work label and sweep across other workdays/);
assert.match(indexHtml, /id="addExpenseShortcutBtn">＋ Expense/);
assert.doesNotMatch(indexHtml, /id="invoiceSettingsBtn"/);
assert.match(indexHtml, /id="invoiceSettingsFromSettings"/);
assert.match(completeCss, /Revision 9 — Calendar Sweep invoice builder/);
assert.match(completeCss, /\.invoice-calendar-grid\{touch-action:none/);
assert.match(completeCss, /Revision 11 — Paired clocks and client quick times/);
assert.match(completeCss, /\.paired-clock-picker/);
assert.match(completeCss, /@keyframes quickTimeFizzle/);

function elementStub() {
  const listeners = {};
  const classes = new Set();
  return {
    value: '', textContent: '', innerHTML: '', hidden: false, dataset: {},
    setCustomValidity(message) { this.validationMessage = message; },
    _listeners: listeners,
    style: { setProperty() {}, removeProperty() {} },
    classList: {
      add(...names) { names.forEach(name => classes.add(name)); },
      remove(...names) { names.forEach(name => classes.delete(name)); },
      toggle(name, force) { const active = force === undefined ? !classes.has(name) : Boolean(force); active ? classes.add(name) : classes.delete(name); return active; },
      contains(name) { return classes.has(name); }
    },
    addEventListener(type, callback) { (listeners[type] ||= []).push(callback); }, setAttribute() {}, removeAttribute() {}, focus() {},
    matches() { return false; }, contains() { return false; },
    querySelector() { return null; }, querySelectorAll() { return []; },
    getBoundingClientRect() { return { height: 1, width: 1 }; }, scrollIntoView() {}
  };
}

function boot(seed, extraStore = {}) {
  const elements = new Map();
  const snapshotTab = elementStub(); snapshotTab.dataset.homeTab = 'snapshot';
  const analyticsTab = elementStub(); analyticsTab.dataset.homeTab = 'analytics';
  const snapshotPanel = elementStub(); snapshotPanel.dataset.homePanel = 'snapshot';
  const analyticsPanel = elementStub(); analyticsPanel.dataset.homePanel = 'analytics';
  const selectorGroups = new Map([
    ['[data-home-tab]', [snapshotTab, analyticsTab]],
    ['[data-home-panel]', [snapshotPanel, analyticsPanel]]
  ]);
  const one = selector => {
    if (!elements.has(selector)) elements.set(selector, elementStub());
    return elements.get(selector);
  };
  const store = new Map([['business-ledger:v0.2', JSON.stringify(seed)], ...Object.entries(extraStore)]);
  const document = {
    querySelector: one, querySelectorAll: selector => selectorGroups.get(selector) || [], addEventListener() {}, hidden: false,
    activeElement: { tagName: 'BODY' }, body: one('body'), documentElement: one('html'),
    createElement: elementStub
  };
  const window = {
    innerWidth: 1280, innerHeight: 900, addEventListener() {}, scrollTo() {}, open() { return null; },
    matchMedia: () => ({ matches: false, addEventListener() {} })
  };
  const context = {
    console, document, window, navigator: { userAgent: 'Node', platform: 'Linux', maxTouchPoints: 0 },
    localStorage: { getItem: key => store.get(key) || null, setItem: (key, value) => store.set(key, value) },
    requestAnimationFrame: callback => { callback(); return 1; },
    setTimeout: () => 1, clearTimeout() {}, setInterval: () => 1, clearInterval() {},
    structuredClone, Blob, URL, Intl, Date, Math, JSON, Number, String, Map, Set, Array, Object, Boolean, Promise, Error
  };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8'), context, { filename: 'app.js' });
  return { elements, store, home: { snapshotTab, analyticsTab, snapshotPanel, analyticsPanel } };
}

const now = '2026-09-15T12:00:00Z';
const business = { id: 'biz', displayName: 'Play It Forward', entityType: 'Sole proprietor', currency: 'USD', timezone: 'America/Los_Angeles', status: 'active', invoiceSettings: { prefix: 'INV', nextNumber: 2, defaultDueDays: 7 }, createdAt: now, updatedAt: now };
const seed = {
  schemaVersion: 9, activeBusinessId: 'biz', businesses: [business],
  clients: [{ id: 'client', businessId: 'biz', displayName: 'Client One', status: 'active', defaultRateCents: 5000, colorKey: 'blue' }],
  sessions: [{ id: 'session', businessId: 'biz', clientId: 'client', clientNameSnapshot: 'Client One', date: '2026-09-10', startTime: '10:00', endTime: '12:00', rateCents: 5000, invoiceStatus: 'invoiced', invoiceId: 'invoice' }],
  invoices: [{ id: 'invoice', businessId: 'biz', number: 'INV-1', clientId: 'client', recipientSnapshot: { displayName: 'Client One' }, issueDate: '2026-09-10', dueDate: '2026-09-20', status: 'sent', lineItems: [{ type: 'session', sessionId: 'session', description: 'Work', quantityMinutes: 120, rateCents: 5000, amountCents: 10000 }] }],
  payments: [
    { id: 'payment', businessId: 'biz', kind: 'invoice', invoiceId: 'invoice', invoiceNumberSnapshot: 'INV-1', clientNameSnapshot: 'Client One', receivedDate: '2026-09-12', amountCents: 6000, method: 'zelle' },
    { id: 'prior-payment', businessId: 'biz', kind: 'direct', sourceName: 'Prior-period income', receivedDate: '2026-03-10', amountCents: 3000, method: 'zelle' }
  ],
  expenses: [{ id: 'expense', businessId: 'biz', merchant: 'Store', date: '2026-09-13', totalCents: 2000, businessCents: 1500, category: 'supplies', classification: 'mixed', reviewStatus: 'ready' }],
  receipts: [], vehicles: [], mileageTrips: [], auditEvents: [], evidenceSnapshots: []
};

const { elements, store } = boot(seed);
const html = selector => elements.get(selector)?.innerHTML || '';

assert.equal(JSON.parse(store.get('business-ledger:v0.2')).schemaVersion, 9);
assert.match(html('#analyticsKpis'), /\$60/);
assert.match(html('#analyticsKpis'), /\$15/);
assert.match(html('#analyticsKpis'), /\$45/);
assert.match(html('#analyticsKpis'), /2h/);
assert.match(html('#analyticsKpis'), /100% higher/);
assert.match(html('#analyticsCashflowChart'), /chart-line net/);
assert.match(html('#analyticsCashflowChart'), /axis-value/);
assert.match(html('#analyticsCashflowChart'), /chart-scrubber/);
assert.match(html('#analyticsClients'), /Client One/);

// Verify the actual Home control wiring, not only the analytics renderer.
const tabBoot = boot(seed);
tabBoot.home.analyticsTab._listeners.click[0]();
assert.equal(tabBoot.home.analyticsTab.classList.contains('active'), true);
assert.equal(tabBoot.home.analyticsPanel.classList.contains('active'), true);
assert.equal(tabBoot.home.snapshotPanel.classList.contains('active'), false);
tabBoot.home.snapshotTab._listeners.click[0]();
assert.equal(tabBoot.home.snapshotPanel.classList.contains('active'), true);
assert.match(html('#analyticsClients'), /2h logged/);
assert.match(html('#analyticsIncomePie'), /donut-slice/);
assert.match(html('#analyticsIncomePie'), />\$60</);
assert.doesNotMatch(html('#analyticsClients'), /Prior-period income/);
assert.match(html('#analyticsExpenses'), /Supplies/);
assert.match(html('#analyticsExpensePie'), /donut-slice/);
assert.match(html('#analyticsInvoiceHealth'), /\$40/);
assert.match(html('#analyticsInvoiceHealth'), /--collection:60%/);
assert.match(html('#analyticsIncomeExpenseChart'), /chart-line income/);
assert.match(html('#analyticsIncomeExpenseChart'), /chart-line expense/);

const negativeSeed = structuredClone(seed);
negativeSeed.expenses.push({ id: 'large-expense', businessId: 'biz', merchant: 'Equipment', date: '2026-09-14', totalCents: 10000, businessCents: 10000, category: 'equipment', classification: 'business', reviewStatus: 'ready' });
['software','fees','marketing','meals'].forEach((category,index)=>negativeSeed.expenses.push({ id: `extra-${category}`, businessId: 'biz', merchant: category, date: '2026-09-14', totalCents: 100+index, businessCents: 100+index, category, classification: 'business', reviewStatus: 'ready' }));
const negativeBoot = boot(negativeSeed);
assert.match(negativeBoot.elements.get('#analyticsCashflowChart').innerHTML, /−\$/);
assert.match(negativeBoot.elements.get('#analyticsExpensePie').innerHTML, /Other/);

const rememberedBoot = boot(seed, {
  'business-ledger-entry-defaults:v1': JSON.stringify({ biz: { expense: { classification: 'personal', category: 'gas' } } })
});
assert.ok(rememberedBoot.elements.get('#addExpenseShortcutBtn')._listeners.click?.length);
const expenseShortcutBoot = boot(seed);
expenseShortcutBoot.elements.get('#addExpenseShortcutBtn')._listeners.click[0]();
assert.match(expenseShortcutBoot.elements.get('#formFields').innerHTML, /id="expenseCompose"/);
rememberedBoot.elements.get('#addExpenseBtn')._listeners.click[0]();
const expenseFormHtml = rememberedBoot.elements.get('#formFields').innerHTML;
assert.match(expenseFormHtml, /option value="personal" selected>Personal/);
assert.match(expenseFormHtml, /id="expenseCompose"/);
assert.match(expenseFormHtml, /id="expenseClassification" value="personal"/);
assert.match(expenseFormHtml, /option value="gas" selected>Gas/);
assert.match(expenseFormHtml, />Food<\/option>/);
assert.match(expenseFormHtml, />Parking<\/option>/);
assert.match(expenseFormHtml, />Car<\/option>/);
assert.match(expenseFormHtml, />Subscriptions<\/option>/);
assert.match(expenseFormHtml, />Misc<\/option>/);
assert.match(expenseFormHtml, />Fees<\/option>/);
assert.match(expenseFormHtml, />Work Equipment<\/option>/);
assert.doesNotMatch(expenseFormHtml, />Supplies<\/option>/);

// Exercise the real compose listeners without loading sample records in the app.
const compose = rememberedBoot.elements.get('#expenseCompose');
const total = rememberedBoot.elements.get('#expenseTotal');
const merchant = rememberedBoot.elements.get('#expenseMerchant');
function typeCompose(value) { compose.value = value; compose._listeners.input[0](); }
typeCompose('$40 at Shell');
assert.equal(total.value, '40.00');
assert.equal(merchant.value, 'Shell');
assert.equal(compose.validationMessage, '');
assert.equal(rememberedBoot.elements.get('#expenseClassification').value, 'personal');
typeCompose('$1,234.56 at Store 24');
assert.equal(total.value, '1234.56');
assert.equal(merchant.value, 'Store 24');
for (const input of ['$0 at Shell', '$-4 at Shell', '40 at', '40.999 at Shell', '1,23 at Shell']) {
  typeCompose(input);
  assert.ok(compose.validationMessage, input);
}
total._listeners.input[0]();
assert.equal(compose.value, '');
assert.equal(compose.validationMessage, '');
rememberedBoot.elements.get('#expenseUse')._listeners.change[0]({target:{value:'mixed'}});
assert.equal(rememberedBoot.elements.get('#expenseBusinessAmount').required, true);
assert.equal(rememberedBoot.elements.get('#expenseBusinessAmountField').hidden, false);
rememberedBoot.elements.get('#expenseUse')._listeners.change[0]({target:{value:'personal'}});
assert.equal(rememberedBoot.elements.get('#expenseBusinessAmount').disabled, true);
assert.equal(rememberedBoot.elements.get('#expensePurposeField').hidden, true);

const migratedDefaultsBoot = boot(seed);
migratedDefaultsBoot.elements.get('#addExpenseBtn')._listeners.click[0]();
const migratedExpenseFormHtml = migratedDefaultsBoot.elements.get('#formFields').innerHTML;
assert.match(migratedExpenseFormHtml, /id="expenseClassification" value="mixed"/);
assert.match(migratedExpenseFormHtml, /option value="food" selected>Food/);
assert.doesNotMatch(migratedExpenseFormHtml, />Supplies<\/option>/);

// Paired work-session clocks preserve the authoritative start/end fields while
// keeping exactly three UI-only quick times scoped to each workspace + client.
const quickSessionSeed = structuredClone(seed);
quickSessionSeed.clients.push({ id: 'client2', businessId: 'biz', displayName: 'Client Two', status: 'active', defaultRateCents: 4000, colorKey: 'coral' });
const quickSessionBoot = boot(quickSessionSeed, {
  'business-ledger-entry-defaults:v1': JSON.stringify({ biz: { session: { clientId: 'client', startTime: '09:00', endTime: '12:00' } } }),
  'business-ledger-session-quick-times:v1': JSON.stringify({ biz: {
    client: [{ startTime: '09:00', endTime: '12:00' }, null, null],
    client2: [{ startTime: '13:00', endTime: '17:00' }, null, { startTime: '18:00', endTime: '20:00' }]
  } })
});
quickSessionBoot.elements.get('#addSessionBtn')._listeners.click[0]();
const sessionFormHtml = quickSessionBoot.elements.get('#formFields').innerHTML;
assert.match(sessionFormHtml, /id="clockStartDial"/);
assert.match(sessionFormHtml, /id="clockEndDial"/);
assert.match(sessionFormHtml, /id="sessionQuickTimes"/);
assert.match(sessionFormHtml, /name="startTime"/);
assert.match(sessionFormHtml, /name="endTime"/);
assert.equal(quickSessionBoot.elements.get('#formSheet').classList.contains('session-form-sheet'), true);
assert.match(quickSessionBoot.elements.get('#sessionQuickTimes').innerHTML, /9:00 AM/);
assert.match(quickSessionBoot.elements.get('#sessionQuickTimes').innerHTML, /12:00 PM/);
assert.equal((quickSessionBoot.elements.get('#sessionQuickTimes').innerHTML.match(/QUICK/g) || []).length, 3);

const quickApply = elementStub(); quickApply.dataset.quickApply = '0';
const quickEdit = elementStub(); quickEdit.dataset.quickEdit = '0';
const quickHost = quickSessionBoot.elements.get('#sessionQuickTimes');
quickHost.querySelectorAll = selector => selector === '[data-quick-apply]' ? [quickApply] : selector === '[data-quick-edit]' ? [quickEdit] : [];
const quickClient = quickSessionBoot.elements.get('#sessionClient');
quickClient.value = 'client2';
quickClient.selectedOptions = [{ dataset: { rate: '4000', color: 'coral' } }];
quickClient._listeners.change[0]();
assert.equal(quickSessionBoot.elements.get('#sessionClockPicker').dataset.clientColor, 'coral');
assert.match(quickHost.innerHTML, /1:00 PM/);
assert.match(quickHost.innerHTML, /5:00 PM/);
assert.doesNotMatch(quickHost.innerHTML, /9:00 AM/);
quickApply._listeners.click[0]();
assert.equal(quickSessionBoot.elements.get('#clockStartInput').value, '13:00');
assert.equal(quickSessionBoot.elements.get('#clockEndInput').value, '17:00');
quickEdit._listeners.click[0]();
quickSessionBoot.elements.get('#quickTimeStart').value = '14:00';
quickSessionBoot.elements.get('#quickTimeEnd').value = '18:30';
quickSessionBoot.elements.get('#quickTimeSave')._listeners.click[0]();
const savedQuickTimes = JSON.parse(quickSessionBoot.store.get('business-ledger-session-quick-times:v1'));
assert.deepEqual(savedQuickTimes.biz.client2[0], { startTime: '14:00', endTime: '18:30' });
assert.deepEqual(savedQuickTimes.biz.client[0], { startTime: '09:00', endTime: '12:00' });

// The Quick Receive composer mirrors expense entry without guessing accounting links.
const paymentBoot = boot(seed, {
  'business-ledger-entry-defaults:v1': JSON.stringify({ biz: { payment: { kind: 'direct', method: 'cash' } } })
});
paymentBoot.elements.get('#addPaymentBtn')._listeners.click[0]();
const paymentFormHtml = paymentBoot.elements.get('#formFields').innerHTML;
assert.match(paymentFormHtml, /id="paymentCompose"/);
assert.match(paymentFormHtml, /\$750 from Jordan via Zelle/);
assert.match(paymentFormHtml, /id="paymentKindSelect"/);
assert.match(paymentFormHtml, /option value="direct" selected>Other income/);
assert.match(paymentFormHtml, /option value="cash" selected>Cash/);
assert.match(paymentFormHtml, /Link invoice or add details/);
assert.equal(paymentBoot.elements.get('#formSheet').classList.contains('payment-compose-sheet'), true);

const paymentCompose = paymentBoot.elements.get('#paymentCompose');
const paymentAmount = paymentBoot.elements.get('#paymentAmount');
const paymentSource = paymentBoot.elements.get('#paymentSourceName');
const paymentMethod = paymentBoot.elements.get('#paymentMethod');
function typePayment(value) { paymentCompose.value = value; paymentCompose._listeners.input[0](); }
typePayment('$750 from Jordan via Zelle');
assert.equal(paymentAmount.value, '750.00');
assert.equal(paymentSource.value, 'Jordan');
assert.equal(paymentMethod.value, 'zelle');
assert.equal(paymentCompose.validationMessage, '');
assert.equal(paymentBoot.elements.get('#paymentKind').value, 'direct');
typePayment('1,250.50 from Acme Studio via direct deposit');
assert.equal(paymentAmount.value, '1250.50');
assert.equal(paymentSource.value, 'Acme Studio');
assert.equal(paymentMethod.value, 'direct_deposit');
for (const input of ['$0 from Jordan', '$-5 from Jordan', '750 Jordan', '750 from Jordan via crypto']) {
  typePayment(input);
  assert.ok(paymentCompose.validationMessage, input);
}
typePayment('$400 from Jordan via Venmo');
paymentBoot.elements.get('#paymentKindSelect')._listeners.change[0]({ target: { value: 'invoice' } });
assert.equal(paymentBoot.elements.get('#paymentKind').value, 'invoice');
assert.equal(paymentBoot.elements.get('#paymentInvoiceChip').hidden, false);
assert.equal(paymentBoot.elements.get('#paymentDirectChip').hidden, true);
assert.equal(paymentAmount.value, '400.00');
assert.equal(paymentMethod.value, 'venmo');
assert.match(paymentBoot.elements.get('#paymentComposeHint').textContent, /Choose the invoice explicitly/);
paymentAmount._listeners.input[0]();
assert.equal(paymentCompose.value, '');
assert.equal(paymentCompose.validationMessage, '');

// Calendar Sweep filters by client, aggregates same-day work into compact labels,
// preserves client color, and excludes sessions attached to another invoice.
const calendarSeed = structuredClone(seed);
calendarSeed.clients.push({ id: 'client2', businessId: 'biz', displayName: 'Client Two', status: 'active', defaultRateCents: 4000, colorKey: 'coral' });
calendarSeed.sessions.push(
  { id: 'cal-a', businessId: 'biz', clientId: 'client', clientNameSnapshot: 'Client One', date: '2026-09-07', startTime: '08:00', endTime: '09:00', rateCents: 5000, invoiceStatus: 'uninvoiced', invoiceId: null },
  { id: 'cal-b', businessId: 'biz', clientId: 'client', clientNameSnapshot: 'Client One', date: '2026-09-07', startTime: '10:00', endTime: '11:30', rateCents: 5000, invoiceStatus: 'uninvoiced', invoiceId: null },
  { id: 'cal-c', businessId: 'biz', clientId: 'client', clientNameSnapshot: 'Client One', date: '2026-09-15', startTime: '13:00', endTime: '14:00', rateCents: 5000, invoiceStatus: 'uninvoiced', invoiceId: null },
  { id: 'cal-other', businessId: 'biz', clientId: 'client2', clientNameSnapshot: 'Client Two', date: '2026-09-10', startTime: '09:00', endTime: '11:00', rateCents: 4000, invoiceStatus: 'uninvoiced', invoiceId: null }
);
const calendarBoot = boot(calendarSeed, {
  'business-ledger-entry-defaults:v1': JSON.stringify({ biz: { invoice: { clientId: 'client' } } })
});
calendarBoot.elements.get('#addInvoiceBtn')._listeners.click[0]();
assert.match(calendarBoot.elements.get('#invoiceCalendarGrid').innerHTML, /2\.5h · \$125/);
assert.doesNotMatch(calendarBoot.elements.get('#invoiceCalendarGrid').innerHTML, /2h · \$80/);
assert.match(calendarBoot.elements.get('#invoiceSessionChoices').innerHTML, /cal-a/);
assert.doesNotMatch(calendarBoot.elements.get('#invoiceSessionChoices').innerHTML, /cal-other/);
assert.equal(calendarBoot.elements.get('#invoiceSheet').dataset.invoiceClientColor, 'blue');

// A touch tap selects once: pointerdown applies the date and the browser's
// following synthetic click is suppressed instead of undoing the selection.
const tapInput = { value: 'cal-a', checked: false, dataset: { sessionDate: '2026-09-07' } };
const tapButton = elementStub();
tapButton.dataset.invoiceDate = '2026-09-07';
tapButton.closest = () => tapButton;
tapButton.setPointerCapture = () => {};
const sessionChoiceHost = calendarBoot.elements.get('#invoiceSessionChoices');
sessionChoiceHost.querySelectorAll = selector => selector.includes(':checked') ? (tapInput.checked ? [tapInput] : []) : [tapInput];
const calendarGrid = calendarBoot.elements.get('#invoiceCalendarGrid');
calendarGrid.querySelectorAll = selector => selector === '[data-invoice-date]' ? [tapButton] : [];
const tapEvent = { target: tapButton, pointerId: 1, preventDefault() {} };
calendarGrid._listeners.pointerdown[0](tapEvent);
calendarGrid._listeners.pointerup[0]();
calendarGrid._listeners.click[0](tapEvent);
assert.equal(tapInput.checked, true);

const calendarClient = calendarBoot.elements.get('#invoiceClient');
calendarClient.value = 'client2';
calendarClient._listeners.change[0]({ target: calendarClient });
assert.equal(calendarClient.value, 'client');
assert.equal(calendarBoot.elements.get('#invoiceClientChangeConfirm').hidden, false);
sessionChoiceHost.querySelectorAll = () => [];
calendarBoot.elements.get('#confirmInvoiceClient')._listeners.click[0]();
assert.match(calendarBoot.elements.get('#invoiceCalendarGrid').innerHTML, /2h · \$80/);
assert.doesNotMatch(calendarBoot.elements.get('#invoiceCalendarGrid').innerHTML, /2\.5h · \$125/);
assert.match(calendarBoot.elements.get('#invoiceSessionChoices').innerHTML, /cal-other/);
assert.doesNotMatch(calendarBoot.elements.get('#invoiceSessionChoices').innerHTML, /cal-a/);
assert.equal(calendarBoot.elements.get('#invoiceSheet').dataset.invoiceClientColor, 'coral');
assert.match(fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8'), /Selected work will be cleared|selected work was cleared/i);

console.log('Phase 8 analytics, remembered-entry, Quick Receive, and Calendar Sweep smoke test passed.');
